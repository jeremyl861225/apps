/*
 * FFTools: run FFmpeg's command line tools (ffmpeg, ffprobe) as a library
 * inside an iOS app process.
 *
 * Copyright (c) 2026 the Radius developer (an individual developer) <lins.program@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#ifndef FFTOOLS_H
#define FFTOOLS_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 用法（和在 Mac 上叫外部的 ffmpeg／ffprobe 一樣下參數、讀輸出）：
 *
 *   long run = fft_start(FFT_PROGRAM_FFMPEG, argc, argv, callbacks);   // 馬上回來，在背景執行緒跑
 *   fft_cancel(run);                                                     // 要取消時
 *   // 結束時 callbacks.finish(context, 結束碼) 一定會被呼叫剛好一次，之後不會再有任何回呼。
 *
 * - 同一個行程裡同一時間只執行一個（fftools 用了很多全域變數）：其他的照順序排隊。
 *   每次執行前，介接層把 fftools 的全域變數全部還原成剛載入時的樣子；執行後把 libav* 被改過的全域設定（log 等級、CPU 旗標…）改回預設。
 * - 標準輸出：程式印到 stdout 的東西，以及寫到 `pipe:1`（或 `pipe:`）的輸出——例如 `-progress pipe:1` 的進度
 *   （key=value 一行一個，和真的程式一樣）、ffprobe 的 JSON——都交給 output 回呼（一段一段的位元組，不一定剛好一行）。
 *   App 用來算進度的就是這裡的 `-progress` 內容。
 * - 標準錯誤：av_log 的訊息（照 -loglevel 過濾、照 ffmpeg 的格式排好）交給 log 回呼，level 是 AV_LOG_* 的等級；
 *   直接寫到 stderr 的文字 level 是 FFT_LOG_STDERR。
 * - 結束碼和真的程式一樣是 0–255：0 成功；ffmpeg 收到取消是 255（FFT_STATUS_CANCELLED）。
 * - 回呼可能在不同的執行緒上被呼叫，回呼裡不要呼叫 fft_run（會卡住）。
 */

typedef enum FFTProgram {
    FFT_PROGRAM_FFMPEG = 0,
    FFT_PROGRAM_FFPROBE = 1,
} FFTProgram;

/** log 回呼的 level：程式直接寫到 stderr 的文字（不是經過 av_log 的）。 */
#define FFT_LOG_STDERR (-100)
/** 被取消的那一次的結束碼（和 ffmpeg 收到 SIGTERM 時一樣）。 */
#define FFT_STATUS_CANCELLED 255

typedef void (*FFTLogCallback)(void *context, int level, const char *text);
typedef void (*FFTOutputCallback)(void *context, const char *data, size_t length);
typedef void (*FFTFinishCallback)(void *context, int status);

typedef struct FFTCallbacks {
    void *context;
    FFTLogCallback log;         /* 可以是 NULL */
    FFTOutputCallback output;   /* 可以是 NULL */
    FFTFinishCallback finish;   /* 可以是 NULL */
} FFTCallbacks;

/**
 * 排一次執行。argv 不含程式名稱（argv[0] 由介接層補上）；字串會複製，呼叫完就可以釋放。
 * 回傳這一次的編號（> 0），給 fft_cancel 用。
 */
long fft_start(FFTProgram program, int argc, const char *const *argv, FFTCallbacks callbacks);

/**
 * 取消一次執行：還在排隊的從佇列拿掉、馬上結束（finish 在呼叫 fft_cancel 的這條執行緒上被呼叫，之後才回來）；ffmpeg 正在跑的照收到兩次 SIGTERM 的方式馬上停下來（讀寫中斷、不寫檔尾：沒轉完的輸出檔不能用，呼叫的人要刪掉；記憶體照樣清乾淨）。
 * ffprobe 正在跑的會跑完（它很快）。已經結束的不做任何事。結束碼都是 FFT_STATUS_CANCELLED。
 */
void fft_cancel(long run);

/** 同步版：排一次執行並等它結束，回傳結束碼。callbacks.finish 照樣會被呼叫。 */
int fft_run(FFTProgram program, int argc, const char *const *argv, FFTCallbacks callbacks);

/**
 * 和 `ffmpeg -hide_banner -encoders`（encoders 非 0）或 `-decoders` 印出的內容一模一樣，交給 output。
 * 只讀 libavcodec 的清單、不碰 fftools 的全域狀態：不用排隊，正在轉檔時也馬上回來。回傳 0 表示成功。
 */
int fft_list_codecs(int encoders, FFTOutputCallback output, void *context);

/** 診斷用（測試看排隊與執行的次數）。 */
typedef struct FFTStats {
    long started;    /* 開始執行的次數（不含排隊時就取消的） */
    long finished;   /* 結束的次數（含排隊時就取消的） */
    int queued;      /* 正在排隊的數量 */
    int running;     /* 正在執行的數量（0 或 1） */
    size_t global_bytes;  /* 每次執行前還原的 fftools 全域變數大小 */
} FFTStats;
void fft_get_stats(FFTStats *stats);

#ifdef __cplusplus
}
#endif

#endif /* FFTOOLS_H */
