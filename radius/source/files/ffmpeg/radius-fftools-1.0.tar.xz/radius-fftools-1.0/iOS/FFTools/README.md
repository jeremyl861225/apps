# FFTools：在 App 裡反覆執行 ffmpeg／ffprobe 的介接層

Radius iPhone 版的轉檔核心（RadiusCore，和 Mac 版共用）照叫外部程式的方式下 ffmpeg／ffprobe 的參數、讀它們的輸出。
iPhone 不准 App 執行另一支程式，所以把 FFmpeg 上游的 **fftools**（`ffmpeg`、`ffprobe` 這兩支命令列程式的原始碼）編成一個動態 framework，
在 App 的行程裡呼叫。2026-10-15 起取代 FFmpegKitNext（它的包裝層與它改過的 fftools 副本是 LGPL 3），整個 App 裡的 FFmpeg 相關元件都是 **LGPL 2.1 以上**。

- **授權**：LGPL 2.1 以上（和 FFmpeg 相同）。這個資料夾的檔案是我們寫的；fftools 是 FFmpeg 的檔案，修改照 LGPL 2.1 第 2 條標在修補檔裡。
- **不是 FFmpegKit 的程式碼**：沒有參考或複製 FFmpegKit／FFmpegKitNext 的任何原始碼，只從 FFmpeg 9.0.1 官方原始碼的 fftools 改。
- **建置**：`scripts/build_ffmpeg_ios.sh`（下載官方原始碼、驗證 SHA-256、編相依庫與 FFmpeg、套修補、編成 `FFTools.framework`、做成 xcframework 放到 `iOS/Vendor/FFmpeg`）。
- **Swift 這邊**：`iOS/Shared/FFmpegBridge.swift` 把它登記成 RadiusCore 的 `InProcessTools`（"ffmpeg"、"ffprobe"）。測試在 `iOS/Tests/FFToolsTests.swift`。

## 檔案

| 檔案 | 內容 |
|---|---|
| `FFTools.h` | 對外的 C 介面：`fft_start`（排一次執行，回傳編號）、`fft_cancel`、`fft_run`（同步）、`fft_list_codecs`、`fft_get_stats`。說明寫在檔頭。 |
| `fft_bridge.c` | 介接層本體：排隊與專用執行緒、每次執行前還原 fftools 的全域變數、標準輸出／標準錯誤／log 的轉接、取消、結束碼。 |
| `fft_compat.h` | 編 fftools 的每個 .c 時用 `-include` 最先引入：把 `stdout`、`printf`、`vprintf`、`stderr` 接到這一次執行，把寫到 `pipe:`／`pipe:1`／`-` 的 `avio_open`／`avio_open2` 改寫到這一次執行的標準輸出；定義 `FFT_IN_PROCESS`。 |
| `module.modulemap` | Swift 用 `import FFTools`。 |

## 對 FFmpeg 9.0.1 fftools 的修改（要公開的原始碼）

FFmpeg 的函式庫（libavcodec 等）**一行都沒改**；只改了 fftools，全部在 `scripts/patches/fftools-n9.0.1-radius.patch`：

| 檔案 | 改了什麼 | 為什麼 |
|---|---|---|
| `fftools/ffmpeg.c` | `FFT_IN_PROCESS` 時：`term_init()` 不裝 SIGINT／SIGTERM／SIGXCPU／SIGQUIT 的處理、不改終端機設定，只保留忽略 SIGPIPE；新增 `fft_ffmpeg_request_exit()`，設定和收到兩次 SIGTERM 一樣的旗標（`received_sigterm`、`received_nb_signals`＝2，等於命令列連按兩次 Ctrl+C）。 | 在 App 裡不能換掉整個 App 的訊號處理；取消改由介接層呼叫。 |
| `fftools/ffmpeg_opt.c` | `FFT_IN_PROCESS` 時 `stdin_interaction` 預設為 0（等於一律 `-nostdin`）。 | App 沒有終端機，不能等鍵盤或問「要覆蓋嗎？」。 |
| `fftools/ffprobe.c` | `open_input_file()` 裡 5 處 `exit(1)` 改成回傳錯誤（並釋放那時的選項字典）；呼叫的人照原本的流程關檔，ffprobe 的結束碼一樣是 1。 | `exit()` 會結束整個 App。 |

另外編譯時（不是改原始碼）：

- 每個 fftools 的 .c 都 `-include fft_compat.h`（上表）。
- `ffmpeg.c`：`-Dmain=fft_ffmpeg_main`。`ffprobe.c`：`-Dmain=fft_ffprobe_main -Dprogram_name=fft_ffprobe_program_name -Dprogram_birth_year=fft_ffprobe_program_birth_year -Dshow_help_default=fft_ffprobe_show_help_default`
  ——兩支程式原本各有同名的 `main` 等符號，編進同一個 framework 要改名（只改名，行為不變）。
- 編譯參數照 FFmpeg 自己的 Makefile 編 fftools 用的那一套（`make -n fftools/cmdutils.o` 取出）。
- 只匯出 `FFTools.h` 的五個函式（`-exported_symbols_list`）。
- `fftools/resources`（`-print_graphs` 的 HTML 樣板）直接用 FFmpeg 的 Makefile 編出來的物件檔。

## 怎麼做到「同一個行程連跑很多次」

- **同一時間只跑一個**：fftools 用了上百個全域變數，所以一條專用的執行緒（8 MB 堆疊，和一般程式的主執行緒一樣）依序執行，其他的排隊。
  執行時的優先順序（QoS）照呼叫的人。
- **全域變數每次還原**：這個 framework 裡只有 fftools 與介接層。第一次呼叫時把 framework 映像檔的可寫資料區（`__DATA` 的 `__data`、`__bss`、`__common`，約 2 KB）
  整份複製下來，之後每次執行前整份寫回去——等於每次都是剛載入的 fftools（選項的預設值、取消旗標、ffprobe 的設定…），不用一個一個變數追。
  介接層自己要跨次保留的狀態放在 `__DATA,__fft_keep` 區段，不會被寫回。fftools 配置的記憶體由它自己的 cleanup（`ffmpeg_cleanup`、`uninit_opts`）釋放。
- **libav\* 的全域設定**：每次執行前後把 log 的回呼、等級、旗標，`-cpuflags`、`-cpucount`、`-max_alloc` 改過的設定改回預設。
- **命令列程式「反正要結束了」不收的東西**：ffmpeg 只在轉完時關 `-progress` 的輸出，開檔或解析參數就失敗（壞檔、沒有串流、開始轉之前就取消）時不關；
  在 App 裡每次會留下一個管線的寫入端與緩衝區，讀標準輸出的執行緒也要等到逾時才結束。介接層在 ffmpeg 的 `main` 回來之後替它關掉
  （2026-10-15 行為查核發現，`iOS/Tests/FFToolsBehaviorTests.swift` 守著）。
- **標準輸出**：每次執行開一條 pipe，fftools 的 `stdout`（`fdopen` 那條 pipe）與寫到 `pipe:1` 的 avio（改寫成 `pipe:<那條 pipe 的寫入端>`）都進同一條，
  另一條執行緒讀出來交給 `output` 回呼。全部寫入端關閉（或執行結束、讀完剩下的）才算結束，之後不會再有回呼。
- **標準錯誤**：av_log 的訊息照目前的等級過濾、用 `av_log_format_line2` 排成和 ffmpeg 一樣的格式交給 `log` 回呼；直接寫 `stderr` 的（很少）用 `funopen` 接過來。
- **取消**：還在排隊的直接結束；正在跑的 ffmpeg 呼叫 `fft_ffmpeg_request_exit()`（和收到兩次 SIGTERM 一樣：讀寫檔案馬上中斷、在下一個統計週期停下來、記憶體照樣清乾淨，
  但不把佇列裡的畫面轉完、不寫檔尾——轉到一半的檔案 App 反正會刪掉）。2026-10-15 行為查核前是「收到一次 SIGTERM」：要把佇列轉完、編碼器清空、寫完檔尾
  （mp4 的 faststart 還要把整個檔案搬一次）才停，WebM（VP9）在模擬器上要 1.5 秒，這段時間下一個轉檔只能排隊。
  ffprobe 很快，會跑完。被取消的結束碼一律 255。
- **結束碼**：和真的程式一樣 0–255（`main` 回傳負的 AVERROR 時取低 8 位元）。
- **`ffmpeg -encoders`／`-decoders`**：`fft_list_codecs` 直接呼叫 fftools 的 `show_encoders`／`show_decoders`（它們只讀 libavcodec 的清單），輸出接到呼叫的執行緒自己的暫存，不用排隊。

## LGPL 的替換

全部是動態 framework（`FFTools.framework` 與 FFmpeg 的 7 個），App 透過 `@rpath` 載入。原始碼、修補與建置腳本放在「原始碼與建置說明」頁
（`AboutView.sourceCodePage`），可以照著重編、換掉這些 framework 後重新簽章。
