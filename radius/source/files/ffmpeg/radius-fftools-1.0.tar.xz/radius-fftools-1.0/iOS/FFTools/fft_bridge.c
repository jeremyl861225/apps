/*
 * FFTools: run FFmpeg's command line tools (ffmpeg, ffprobe) as a library
 * inside an iOS app process.
 *
 * Copyright (c) 2026 the Radius developer (an individual developer) <lins.program@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/*
 * 介接層本體（介面說明在 FFTools.h）。這個檔不經過 fft_compat.h：這裡的 stdout、avio_open2 是真的。
 *
 * 全域狀態怎麼清：fftools 是寫給「一個行程只跑一次」的程式，用了上百個全域變數與函式內的 static 變數
 * （選項的預設值、已開啟的檔案清單、取消旗標、ffprobe 的 sections 表…），有些在 cleanup 時不會歸零。
 * 這個 framework 裡只有 fftools 與這個檔，所以第一次呼叫時把這個映像檔的可寫資料區（__DATA 的 __data、__bss、__common）
 * 整份複製下來，之後每次執行前整份寫回去——等於每次都是剛載入的 fftools，不用一個一個變數追（漏一個就會互相干擾）。
 * 這個檔自己要跨次保留的狀態（排隊、鎖、快照本身）放在另一個區段 __DATA,__fft_keep，不會被寫回。
 * fftools 配置的記憶體由它自己的 cleanup（ffmpeg_cleanup、uninit_opts…）釋放；寫回只動全域變數本身。
 * 執行中的那一次結束、它開的執行緒都 join 之後才會寫回（同一時間只跑一個，見 worker_main）。
 */

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <mach-o/loader.h>
#include <sys/qos.h>

#include "libavutil/cpu.h"
#include "libavutil/log.h"
#include "libavutil/mem.h"
#include "libavformat/avio.h"

#include "FFTools.h"

/* fftools 裡的進入點（編譯時改名，見 build_fftools）與 opt_common.c 的清單函式。 */
int fft_ffmpeg_main(int argc, char **argv);
int fft_ffprobe_main(int argc, char **argv);
void fft_ffmpeg_request_exit(void);
int show_encoders(void *optctx, const char *opt, const char *arg);
int show_decoders(void *optctx, const char *opt, const char *arg);
/* ffmpeg.c 的全域變數（ffmpeg.h 有宣告）：`-progress` 的輸出。 */
extern AVIOContext *progress_avio;

FILE *fft_stdout_file(void);
FILE *fft_stderr_file(void);
int fft_avio_open(AVIOContext **s, const char *url, int flags);
int fft_avio_open2(AVIOContext **s, const char *url, int flags,
                   const AVIOInterruptCB *int_cb, AVDictionary **options);

/* 跨次保留、不能被「寫回全域變數」蓋掉的東西都放這個區段。 */
#define FFT_KEEP __attribute__((section("__DATA,__fft_keep")))

typedef struct Job {
    long id;
    FFTProgram program;
    int argc;            /* 含 argv[0] */
    char **argv;
    FFTCallbacks cb;
    qos_class_t qos;     /* 呼叫的人的優先順序：執行時照用 */
    atomic_int cancelled;
    struct Job *next;
} Job;

typedef struct Region {
    void *address;
    size_t size;
    void *pristine;
} Region;

typedef struct Output {   /* 一次執行的標準輸出：pipe＋讀取的執行緒 */
    int read_fd, write_fd;
    pthread_t reader;
    atomic_int stop;
    Job *job;
} Output;

static struct {
    pthread_mutex_t lock;
    pthread_cond_t wake;
    Job *head, *tail;
    int queued;
    Job *current;          /* 正在執行的那一次（受 lock 保護） */
    long next_id;
    long started, finished;
    pthread_t worker;

    Region regions[8];
    int nb_regions;
    size_t global_bytes;

    /* 正在執行的那一次的標準輸出、標準錯誤（只有 worker 會改；fftools 的執行緒只讀） */
    FILE *out_file, *err_file;
    int out_fd;            /* pipe 的寫入端，給 pipe:1 用；沒在執行時是 -1 */

    pthread_mutex_t log_lock;
    Job *log_job;          /* 受 log_lock 保護：log 回呼要交給誰（結束後設 NULL，晚到的 log 直接丟掉） */
    int print_prefix;
} S FFT_KEEP;

static pthread_once_t init_once FFT_KEEP = PTHREAD_ONCE_INIT;

/* fft_list_codecs 在呼叫的執行緒上印清單：只影響那條執行緒的 stdout。 */
static __thread FILE *thread_stdout;

/* ───────────────────────── 全域變數的快照與還原 ───────────────────────── */

static void snapshot_globals(void)
{
    Dl_info info;
    if (!dladdr((const void *)&fft_start, &info) || !info.dli_fbase)
        abort();
    const struct mach_header_64 *header = info.dli_fbase;
    if (header->magic != MH_MAGIC_64)
        abort();

    /* 載入位置的位移：__TEXT 的 vmaddr 對應到 header 的實際位址。 */
    intptr_t slide = 0;
    const struct load_command *cmd = (const void *)(header + 1);
    for (uint32_t i = 0; i < header->ncmds; i++, cmd = (const void *)((const char *)cmd + cmd->cmdsize)) {
        if (cmd->cmd != LC_SEGMENT_64)
            continue;
        const struct segment_command_64 *seg = (const void *)cmd;
        if (!strcmp(seg->segname, "__TEXT"))
            slide = (intptr_t)header - (intptr_t)seg->vmaddr;
    }

    cmd = (const void *)(header + 1);
    for (uint32_t i = 0; i < header->ncmds; i++, cmd = (const void *)((const char *)cmd + cmd->cmdsize)) {
        if (cmd->cmd != LC_SEGMENT_64)
            continue;
        const struct segment_command_64 *seg = (const void *)cmd;
        /* 只看可寫的資料段（__DATA、__DATA_DIRTY）；__DATA_CONST 載入後唯讀，裡面只有常數與匯入的指標。 */
        if (strncmp(seg->segname, "__DATA", 6) || !strcmp(seg->segname, "__DATA_CONST"))
            continue;
        const struct section_64 *sect = (const void *)(seg + 1);
        for (uint32_t j = 0; j < seg->nsects; j++, sect++) {
            if (strcmp(sect->sectname, "__data") && strcmp(sect->sectname, "__bss") && strcmp(sect->sectname, "__common"))
                continue;
            if (!sect->size)
                continue;
            if (S.nb_regions >= (int)(sizeof(S.regions) / sizeof(S.regions[0])))
                abort();
            Region *r = &S.regions[S.nb_regions++];
            r->address = (void *)(sect->addr + slide);
            r->size = sect->size;
            r->pristine = malloc(r->size);
            if (!r->pristine)
                abort();
            memcpy(r->pristine, r->address, r->size);
            S.global_bytes += r->size;
        }
    }
}

static void restore_globals(void)
{
    for (int i = 0; i < S.nb_regions; i++)
        memcpy(S.regions[i].address, S.regions[i].pristine, S.regions[i].size);
}

/* libav* 裡會被 fftools 的選項改掉的全域設定，改回預設（-loglevel、-cpuflags、-cpucount、-max_alloc、-report）。 */
static void log_callback(void *avcl, int level, const char *fmt, va_list vl);

static void reset_library_state(void)
{
    av_log_set_callback(log_callback);
    av_log_set_level(AV_LOG_INFO);
    av_log_set_flags(0);
    av_force_cpu_flags(-1);
    av_cpu_force_count(0);
    av_max_alloc(INT_MAX);
}

/* ───────────────────────── 標準輸出、標準錯誤、log ───────────────────────── */

FILE *fft_stdout_file(void)
{
    FILE *f = thread_stdout;
    if (f)
        return f;
    f = S.out_file;
    return f ? f : stdout;
}

FILE *fft_stderr_file(void)
{
    FILE *f = S.err_file;
    return f ? f : stderr;
}

/* 寫到標準輸出的網址：pipe:、pipe:1、-、/dev/stdout。讀取（pipe:0）不動。 */
static const char *map_output_url(const char *url, int flags, char *buffer, size_t size)
{
    int fd = S.out_fd;
    if (!url || !(flags & AVIO_FLAG_WRITE) || fd < 0)
        return url;
    if (strcmp(url, "pipe:") && strcmp(url, "pipe:1") && strcmp(url, "-") && strcmp(url, "/dev/stdout"))
        return url;
    snprintf(buffer, size, "pipe:%d", fd);
    return buffer;
}

int fft_avio_open(AVIOContext **s, const char *url, int flags)
{
    char buffer[32];
    return avio_open(s, map_output_url(url, flags, buffer, sizeof(buffer)), flags);
}

int fft_avio_open2(AVIOContext **s, const char *url, int flags,
                   const AVIOInterruptCB *int_cb, AVDictionary **options)
{
    char buffer[32];
    return avio_open2(s, map_output_url(url, flags, buffer, sizeof(buffer)), flags, int_cb, options);
}

static void deliver_log(int level, const char *text)
{
    Job *job = S.log_job;
    if (job && job->cb.log && *text)
        job->cb.log(job->cb.context, level, text);
}

/* av_log 的訊息：照目前的 log 等級過濾，照 ffmpeg 預設的格式（[元件 @ 位址] 前綴）排好，交給這一次執行。 */
static void log_callback(void *avcl, int level, const char *fmt, va_list vl)
{
    int plain = level >= 0 ? (level & 0xff) : level;
    if (plain > av_log_get_level())
        return;
    char line[4096];
    pthread_mutex_lock(&S.log_lock);
    if (S.log_job) {
        int prefix = S.print_prefix;   /* 很長的一行要重新格式化一次，前綴的狀態要從同一個起點 */
        va_list copy;
        va_copy(copy, vl);
        int needed = av_log_format_line2(avcl, plain, fmt, copy, line, sizeof(line), &S.print_prefix);
        va_end(copy);
        char *big = needed >= (int)sizeof(line) ? malloc((size_t)needed + 1) : NULL;
        if (big) {
            /* 很長的一行（例如整串濾鏡參數）：另外配置，不截斷。 */
            S.print_prefix = prefix;
            va_copy(copy, vl);
            av_log_format_line2(avcl, plain, fmt, copy, big, needed + 1, &S.print_prefix);
            va_end(copy);
            deliver_log(plain, big);
            free(big);
        } else if (needed > 0) {
            deliver_log(plain, line);
        }
    }
    pthread_mutex_unlock(&S.log_lock);
}

/* 程式直接寫到 stderr 的文字（funopen 的寫入函式）。 */
static int stderr_write(void *cookie, const char *data, int length)
{
    (void)cookie;
    char *text = malloc((size_t)length + 1);
    if (!text)
        return length;
    memcpy(text, data, (size_t)length);
    text[length] = 0;
    pthread_mutex_lock(&S.log_lock);
    deliver_log(FFT_LOG_STDERR, text);
    pthread_mutex_unlock(&S.log_lock);
    free(text);
    return length;
}

/* 讀標準輸出的 pipe，一段一段交給 output 回呼。全部寫入端都關了（EOF）就結束；
 * 萬一還有寫入端沒關（不該發生），worker 設 stop 之後，讀完 pipe 裡剩下的也會結束，不會卡住下一次。 */
static void *reader_main(void *arg)
{
    Output *out = arg;
    char buffer[16384];
    pthread_setname_np("fftools.stdout");
    for (;;) {
        struct pollfd p = { .fd = out->read_fd, .events = POLLIN };
        int ready = poll(&p, 1, 100);
        if (ready < 0) {
            if (errno == EINTR)
                continue;
            break;
        }
        if (ready == 0) {
            if (atomic_load(&out->stop))
                break;
            continue;
        }
        ssize_t n = read(out->read_fd, buffer, sizeof(buffer));
        if (n > 0) {
            if (out->job->cb.output)
                out->job->cb.output(out->job->cb.context, buffer, (size_t)n);
        } else if (n == 0 || (errno != EINTR && errno != EAGAIN)) {
            break;
        }
    }
    return NULL;
}

static int open_output(Output *out, Job *job)
{
    int fds[2];
    memset(out, 0, sizeof(*out));
    out->read_fd = out->write_fd = -1;
    out->job = job;
    if (pipe(fds) < 0)
        return -1;
    fcntl(fds[0], F_SETFD, FD_CLOEXEC);
    fcntl(fds[1], F_SETFD, FD_CLOEXEC);
    out->read_fd = fds[0];
    out->write_fd = fds[1];
    if (pthread_create(&out->reader, NULL, reader_main, out)) {
        close(fds[0]);
        close(fds[1]);
        return -1;
    }
    return 0;
}

static void close_output(Output *out)
{
    if (out->write_fd >= 0)
        close(out->write_fd);
    atomic_store(&out->stop, 1);
    pthread_join(out->reader, NULL);
    close(out->read_fd);
}

/* ───────────────────────── 執行 ───────────────────────── */

static int run_job(Job *job)
{
    Output out;
    if (open_output(&out, job) < 0)
        return 1;
    int dup_fd = dup(out.write_fd);
    FILE *out_file = dup_fd >= 0 ? fdopen(dup_fd, "w") : NULL;
    FILE *err_file = funopen(NULL, NULL, stderr_write, NULL, NULL);
    if (!out_file || !err_file) {
        if (out_file) fclose(out_file); else if (dup_fd >= 0) close(dup_fd);
        if (err_file) fclose(err_file);
        close_output(&out);
        return 1;
    }
    setvbuf(out_file, NULL, _IOLBF, 0);
    setvbuf(err_file, NULL, _IONBF, 0);

    pthread_mutex_lock(&S.log_lock);
    S.log_job = job;
    S.print_prefix = 1;
    pthread_mutex_unlock(&S.log_lock);
    S.out_file = out_file;
    S.err_file = err_file;
    S.out_fd = out.write_fd;
    reset_library_state();

    /* fftools 可能改動 argv 陣列本身，給它一份淺複本；字串由 job 持有到結束。 */
    char **argv = calloc((size_t)job->argc + 1, sizeof(char *));
    int ret = 1;
    if (argv) {
        memcpy(argv, job->argv, (size_t)job->argc * sizeof(char *));
        ret = job->program == FFT_PROGRAM_FFPROBE ? fft_ffprobe_main(job->argc, argv)
                                                  : fft_ffmpeg_main(job->argc, argv);
        free(argv);
    }
    /* fftools 只在轉完時（print_report 的最後一次）關掉 `-progress` 的輸出；開檔、解析參數就失敗（壞檔、沒有串流、
     * 開始轉之前就取消）時，命令列程式反正要結束了不管它。在 App 裡會每次留下一個管線的寫入端（讀標準輸出的執行緒
     * 收不到 EOF、要等到逾時）和它的緩衝區，下一次執行前全域變數還原成 NULL 之後就再也關不掉了。這裡替它關。 */
    if (job->program == FFT_PROGRAM_FFMPEG && progress_avio)
        avio_closep(&progress_avio);

    fflush(out_file);
    S.out_file = NULL;
    S.err_file = NULL;
    S.out_fd = -1;
    fclose(out_file);
    fclose(err_file);
    close_output(&out);
    reset_library_state();
    pthread_mutex_lock(&S.log_lock);
    S.log_job = NULL;
    pthread_mutex_unlock(&S.log_lock);

    /* 結束碼照真的程式（0–255）；main 回傳負的 AVERROR 時，行程的結束碼是它的低 8 位元（不會剛好是 0，保險起見還是擋一下）。 */
    if (atomic_load(&job->cancelled))
        return FFT_STATUS_CANCELLED;
    if (ret == 0)
        return 0;
    return (ret & 0xff) ? (ret & 0xff) : 1;
}

static void free_job(Job *job)
{
    for (int i = 0; i < job->argc; i++)
        free(job->argv[i]);
    free(job->argv);
    free(job);
}

static void *worker_main(void *unused)
{
    (void)unused;
    pthread_setname_np("fftools");
    pthread_mutex_lock(&S.lock);
    for (;;) {
        while (!S.head)
            pthread_cond_wait(&S.wake, &S.lock);
        Job *job = S.head;
        S.head = job->next;
        if (!S.head)
            S.tail = NULL;
        S.queued--;
        int skip = atomic_load(&job->cancelled);
        if (!skip) {
            restore_globals();     /* 這之後才設 current：取消要改的旗標不會被寫回蓋掉 */
            S.current = job;
            S.started++;
        }
        pthread_mutex_unlock(&S.lock);

        int status = FFT_STATUS_CANCELLED;
        if (!skip) {
            pthread_set_qos_class_self_np(job->qos, 0);
            status = run_job(job);
            pthread_set_qos_class_self_np(QOS_CLASS_UTILITY, 0);
        }

        pthread_mutex_lock(&S.lock);
        S.current = NULL;
        S.finished++;
        pthread_mutex_unlock(&S.lock);
        if (job->cb.finish)
            job->cb.finish(job->cb.context, status);
        free_job(job);
        pthread_mutex_lock(&S.lock);
    }
    return NULL;
}

static void initialize(void)
{
    pthread_mutex_init(&S.lock, NULL);
    pthread_cond_init(&S.wake, NULL);
    pthread_mutex_init(&S.log_lock, NULL);
    S.next_id = 1;
    S.out_fd = -1;
    snapshot_globals();
    av_log_set_callback(log_callback);

    /* 一條專用的執行緒依序執行。堆疊和一般程式的主執行緒一樣大（fftools 是寫給主執行緒的）。 */
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 8 * 1024 * 1024);
    pthread_attr_set_qos_class_np(&attr, QOS_CLASS_UTILITY, 0);
    if (pthread_create(&S.worker, &attr, worker_main, NULL))
        abort();
    pthread_attr_destroy(&attr);
    pthread_detach(S.worker);
}

long fft_start(FFTProgram program, int argc, const char *const *argv, FFTCallbacks callbacks)
{
    pthread_once(&init_once, initialize);
    Job *job = calloc(1, sizeof(*job));
    char **copy = job ? calloc((size_t)argc + 2, sizeof(char *)) : NULL;
    if (!copy) {
        free(job);
        if (callbacks.finish)
            callbacks.finish(callbacks.context, 1);
        return 0;
    }
    copy[0] = strdup(program == FFT_PROGRAM_FFPROBE ? "ffprobe" : "ffmpeg");
    for (int i = 0; i < argc; i++)
        copy[i + 1] = strdup(argv[i] ? argv[i] : "");
    job->program = program;
    job->argc = argc + 1;
    job->argv = copy;
    job->cb = callbacks;
    job->qos = qos_class_self();
    if (job->qos == QOS_CLASS_UNSPECIFIED)
        job->qos = QOS_CLASS_DEFAULT;
    atomic_init(&job->cancelled, 0);

    pthread_mutex_lock(&S.lock);
    job->id = S.next_id++;
    if (S.tail)
        S.tail->next = job;
    else
        S.head = job;
    S.tail = job;
    S.queued++;
    long id = job->id;
    pthread_cond_signal(&S.wake);
    pthread_mutex_unlock(&S.lock);
    return id;
}

void fft_cancel(long run)
{
    if (run <= 0)
        return;
    pthread_once(&init_once, initialize);
    Job *removed = NULL;
    pthread_mutex_lock(&S.lock);
    /* 還在排隊：從佇列拿掉，馬上結束（不用等前面的跑完）。 */
    for (Job **link = &S.head; *link; link = &(*link)->next) {
        if ((*link)->id != run)
            continue;
        removed = *link;
        *link = removed->next;
        if (S.tail == removed) {
            S.tail = NULL;
            for (Job *job = S.head; job; job = job->next)
                S.tail = job;
        }
        S.queued--;
        S.finished++;
        break;
    }
    /* 正在跑：ffmpeg 照收到兩次 SIGTERM 的方式馬上停下來（不寫檔尾）；ffprobe 很快，讓它跑完。結束碼一律 FFT_STATUS_CANCELLED。 */
    if (!removed && S.current && S.current->id == run) {
        atomic_store(&S.current->cancelled, 1);
        if (S.current->program == FFT_PROGRAM_FFMPEG)
            fft_ffmpeg_request_exit();
    }
    pthread_mutex_unlock(&S.lock);
    if (removed) {
        if (removed->cb.finish)
            removed->cb.finish(removed->cb.context, FFT_STATUS_CANCELLED);
        free_job(removed);
    }
}

typedef struct SyncWait {
    pthread_mutex_t lock;
    pthread_cond_t done_cond;
    int done;
    int status;
    FFTCallbacks inner;
} SyncWait;

static void sync_log(void *context, int level, const char *text)
{
    SyncWait *w = context;
    if (w->inner.log)
        w->inner.log(w->inner.context, level, text);
}

static void sync_output(void *context, const char *data, size_t length)
{
    SyncWait *w = context;
    if (w->inner.output)
        w->inner.output(w->inner.context, data, length);
}

static void sync_finish(void *context, int status)
{
    SyncWait *w = context;
    if (w->inner.finish)
        w->inner.finish(w->inner.context, status);
    pthread_mutex_lock(&w->lock);
    w->status = status;
    w->done = 1;
    pthread_cond_signal(&w->done_cond);
    pthread_mutex_unlock(&w->lock);
}

int fft_run(FFTProgram program, int argc, const char *const *argv, FFTCallbacks callbacks)
{
    pthread_once(&init_once, initialize);
    if (pthread_equal(pthread_self(), S.worker))
        return 1;   /* 在回呼裡呼叫會等自己：不准 */
    SyncWait w = { .inner = callbacks };
    pthread_mutex_init(&w.lock, NULL);
    pthread_cond_init(&w.done_cond, NULL);
    FFTCallbacks mine = { .context = &w, .log = sync_log, .output = sync_output, .finish = sync_finish };
    fft_start(program, argc, argv, mine);
    pthread_mutex_lock(&w.lock);
    while (!w.done)
        pthread_cond_wait(&w.done_cond, &w.lock);
    pthread_mutex_unlock(&w.lock);
    pthread_cond_destroy(&w.done_cond);
    pthread_mutex_destroy(&w.lock);
    return w.status;
}

int fft_list_codecs(int encoders, FFTOutputCallback output, void *context)
{
    pthread_once(&init_once, initialize);
    char *text = NULL;
    size_t length = 0;
    FILE *f = open_memstream(&text, &length);
    if (!f)
        return 1;
    thread_stdout = f;
    int ret = encoders ? show_encoders(NULL, NULL, NULL) : show_decoders(NULL, NULL, NULL);
    thread_stdout = NULL;
    fclose(f);
    if (ret >= 0 && output && length)
        output(context, text, length);
    free(text);
    return ret < 0 ? 1 : 0;
}

void fft_get_stats(FFTStats *stats)
{
    pthread_once(&init_once, initialize);
    pthread_mutex_lock(&S.lock);
    stats->started = S.started;
    stats->finished = S.finished;
    stats->queued = S.queued;
    stats->running = S.current ? 1 : 0;
    stats->global_bytes = S.global_bytes;
    pthread_mutex_unlock(&S.lock);
}
