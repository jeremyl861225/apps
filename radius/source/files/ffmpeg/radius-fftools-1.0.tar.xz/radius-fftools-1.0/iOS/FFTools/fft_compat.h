/*
 * FFTools: forced include for FFmpeg's fftools sources when they are built
 * as a library that runs inside an app process (see fft_bridge.c).
 *
 * Copyright (c) 2026 the Radius developer (an individual developer) <lins.program@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/*
 * 每個 fftools 的 .c 檔編譯時用 -include 最先引入（scripts/build_ffmpeg_ios.sh 的 build_fftools）。
 * 同一個 App 行程裡沒有「這支程式自己的」標準輸出與標準錯誤，所以：
 *  - stdout、printf、vprintf → 這一次執行的標準輸出（交給 FFTCallbacks.output）；
 *  - stderr → 這一次執行的標準錯誤（交給 FFTCallbacks.log，level 為 FFT_LOG_STDERR）；
 *  - avio_open／avio_open2 寫到 `pipe:`、`pipe:1`、`-`（ffmpeg 的 -progress、-stats_enc_post 等）→ 改寫到這一次執行的標準輸出。
 * FFT_IN_PROCESS 給 scripts/patches/fftools-*-radius.patch 裡的修改判斷用。
 */
#ifndef FFT_COMPAT_H
#define FFT_COMPAT_H

#define FFT_IN_PROCESS 1

#include "config.h"
#include <stdio.h>
#include "libavformat/avio.h"

FILE *fft_stdout_file(void);
FILE *fft_stderr_file(void);
int fft_avio_open(AVIOContext **s, const char *url, int flags);
int fft_avio_open2(AVIOContext **s, const char *url, int flags,
                   const AVIOInterruptCB *int_cb, AVDictionary **options);
void fft_ffmpeg_request_exit(void);
/* ffmpeg.c、ffprobe.c 的 main 編譯時改名成這兩個（-Dmain=…），在這裡先宣告。 */
int fft_ffmpeg_main(int argc, char **argv);
int fft_ffprobe_main(int argc, char **argv);

#undef stdout
#define stdout (fft_stdout_file())
#undef stderr
#define stderr (fft_stderr_file())
#define printf(...) fprintf(stdout, __VA_ARGS__)
#define vprintf(fmt, vl) vfprintf(stdout, fmt, vl)
#define avio_open(s, url, flags) fft_avio_open(s, url, flags)
#define avio_open2(s, url, flags, int_cb, options) fft_avio_open2(s, url, flags, int_cb, options)

#endif /* FFT_COMPAT_H */
