# radius-fftools-1.0

FFmpeg build scripts and the FFTools interface layer used by **Radius 1.0 for iPhone**
(bundle ID `com.jeremyl861225.radius`, version 1.0, build 1).
Everything in this archive is licensed under the **GNU Lesser General Public License, version 2.1 or later**
(see `COPYING.LGPLv2.1`).

Source code page: https://jeremyl861225.github.io/apps/radius/source/
Contact: lins.program@gmail.com

## What is in here

| Path | What it is |
|---|---|
| `scripts/build_ffmpeg_ios.sh` | Builds LAME, Opus, libvpx, libwebp, FFmpeg 9.0.1 and FFTools for iOS (arm64 device and arm64 simulator, minimum iOS 18) and packages them as dynamic xcframeworks. Comments are in Traditional Chinese. |
| `scripts/patches/fftools-n9.0.1-radius.patch` | Our only changes to FFmpeg: three files under `fftools/` (`ffmpeg.c`, `ffmpeg_opt.c`, `ffprobe.c`). The FFmpeg libraries themselves (libavcodec, libavformat, …) are **not modified**. |
| `iOS/FFTools/` | FFTools: the layer that runs `ffmpeg` and `ffprobe` (built from FFmpeg's own `fftools/` sources) as a library inside the app process. `FFTools.h` is the C interface the app calls; `README.md` is the design note (Traditional Chinese). |
| `BUILD-INFO-1.0.txt` | What the shipped Radius 1.0 frameworks were built from: the license line printed by FFmpeg's `configure`, the complete `configure` command line, and the URL and SHA-256 of every upstream tarball. |
| `COPYING.LGPLv2.1` | The license (taken from the FFmpeg 9.0.1 source tarball). |

The upstream source tarballs (FFmpeg 9.0.1, LAME 3.100, Opus 1.5.2, libvpx 1.16.0, libwebp 1.6.0) are published next to
this archive on the source code page, unmodified, with their SHA-256 checksums.

## How the frameworks are built

- **FFmpeg 9.0.1** from the official release tarball, configured with `--disable-gpl --disable-version3 --disable-nonfree`.
  The script stops unless `configure` reports `License: LGPL version 2.1 or later`.
- External libraries (all unmodified official releases, statically linked into `libavcodec`): LAME 3.100 (encoder only, LGPL 2.0 or later),
  Opus 1.5.2, libvpx 1.16.0, libwebp 1.6.0 (BSD 3-Clause). From iOS itself: zlib, bzip2, iconv, VideoToolbox, AudioToolbox.
- **FFTools.framework**: FFmpeg's `fftools` sources with the patch above, compiled with `-include iOS/FFTools/fft_compat.h` and a few
  symbol renames (`-Dmain=fft_ffmpeg_main`, …; see the script), plus `iOS/FFTools/fft_bridge.c`. Only the functions declared in
  `FFTools.h` are exported.
- Every library is a **dynamic framework** loaded through `@rpath`, so it can be replaced (see below).

## Rebuilding

Requirements: a Mac with Apple silicon, Xcode 27 (iOS 27 SDK), and `brew install pkgconf cmake autoconf automake libtool`.
The work directory must not contain spaces (FFmpeg's `configure` does not support them).

```sh
tar xf radius-fftools-1.0.tar.xz
export RADIUS_FFMPEG_WORK="$HOME/radius-ffmpeg-work"   # sources and intermediate files go here
# Optional: use the tarballs from the source code page instead of downloading them from upstream.
mkdir -p "$RADIUS_FFMPEG_WORK/downloads"
cp ffmpeg-9.0.1.tar.xz lame-3.100.tar.gz opus-1.5.2.tar.gz libvpx-1.16.0.tar.gz libwebp-1.6.0.tar.gz "$RADIUS_FFMPEG_WORK/downloads/"
cd radius-fftools-1.0
JOBS=8 scripts/build_ffmpeg_ios.sh        # all steps; about 25 minutes on an 8 GB Mac with JOBS=3
```

The script checks the SHA-256 of every tarball, then writes `iOS/Vendor/FFmpeg/` inside this directory:
eight xcframeworks (`FFTools`, `libavcodec`, `libavdevice`, `libavfilter`, `libavformat`, `libavutil`, `libswresample`, `libswscale`),
each with an `ios-arm64` (device) and an `ios-arm64-simulator` slice, plus `Package.swift` and a fresh `BUILD-INFO.txt`.
Single steps: `scripts/build_ffmpeg_ios.sh fetch | deps device | ffmpeg device | fftools device | package` (see the header of the script).

To build a **modified FFmpeg**: put your tarball at `$RADIUS_FFMPEG_WORK/downloads/ffmpeg-9.0.1.tar.xz` (top-level folder `ffmpeg-9.0.1/`)
and replace `FFMPEG_SHA256` near the top of the script with its SHA-256. The fftools patch must still apply to your tree.

## Replacing FFmpeg in the app

In the app bundle (`RadiusPhone.app`, shown on the Home Screen as “Radius”) the libraries are separate dynamic frameworks:

```
RadiusPhone.app/Frameworks/FFTools.framework/FFTools
RadiusPhone.app/Frameworks/libavcodec.framework/libavcodec        (63.1.101, includes LAME, Opus, libvpx, libwebp)
RadiusPhone.app/Frameworks/libavdevice.framework/libavdevice      (63.1.101)
RadiusPhone.app/Frameworks/libavfilter.framework/libavfilter      (12.1.101)
RadiusPhone.app/Frameworks/libavformat.framework/libavformat      (63.1.101)
RadiusPhone.app/Frameworks/libavutil.framework/libavutil          (61.1.101)
RadiusPhone.app/Frameworks/libswresample.framework/libswresample  (7.1.101)
RadiusPhone.app/Frameworks/libswscale.framework/libswscale        (10.1.101)
```

The app (`RadiusPhone`) and its share extension (`PlugIns/RadiusShare.appex`, which loads the same frameworks through
`@executable_path/../../Frameworks`) reference them by install name `@rpath/<name>.framework/<name>`.
The app's own code calls only the C functions declared in `FFTools.h` (`fft_start`, `fft_cancel`, `fft_run`, `fft_list_codecs`);
it does not call FFmpeg library functions directly. A replacement therefore has to:

1. keep the framework names and install names (the script already does this);
2. export the `FFTools.h` interface with the same signatures and behavior (exit codes, output and log callbacks);
3. keep the same library major versions as above (FFmpeg 9.0.x), or rebuild FFTools against your FFmpeg so the two match.

Steps:

1. Build as described above (with your changes) and take the device slices from
   `iOS/Vendor/FFmpeg/<name>.xcframework/ios-arm64/<name>.framework/`.
2. In a copy of the app bundle, replace each `Frameworks/<name>.framework/<name>` binary with yours.
3. Re-sign with your own Apple signing identity and provisioning profiles, innermost first:
   the eight frameworks, then `PlugIns/RadiusShare.appex`, then `RadiusPhone.app`
   (for example `codesign --force --sign "<your identity>" --entitlements <file> <path>`; the bundle IDs, App Group and
   `embedded.mobileprovision` have to match identifiers registered to your developer team).
4. Install it on your device, for example with Xcode › Devices and Simulators or
   `xcrun devicectl device install app --device <device> RadiusPhone.app`.

## Written offer

For at least three years after the last distribution of Radius 1.0, anyone who received it can ask for these sources
by email at lins.program@gmail.com; we charge no more than the cost of providing them.
